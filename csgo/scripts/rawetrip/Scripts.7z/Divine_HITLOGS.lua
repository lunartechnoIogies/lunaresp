local fonts = {
	default = render.setup_font("Verdana", 14)
}

render.measure_multitext = function(_table)
    local a = 0

    for b, c in pairs(_table) do
        if not c.font then
            return
        end

        a = a + render.get_text_width(c.font, c.text)
    end

    return a
end

render.multitext = function(x, y, _table)
    for a, b in pairs(_table) do
        if not b.font then
            return
        end

        b.shadow = b.shadow or false
        b.outline = b.outline or false
        b.color = b.color or color.new(255, 255, 255, 255)

        render.text(b.font, x, y, b.color, b.text, b.shadow, b.outline)

        x = x + render.get_text_width(b.font, b.text)
    end
end

ui.add_sliderint("lifetime", 1, 10)
ui.add_sliderint("max logs", 1, 16)
ui.add_sliderint("logs offset", 0, 200)
ui.add_combobox("animation", {"none", "left", "bottom"})
ui.add_colorpicker("color")

hitlogs = {lifetime = 1}
hitlogs_list = {}
hitlogs_groups = {"generic", "head", "chest", "stomach", "left arm", "right arm", "left leg", "right leg", "neck", "?", "gear"}
function hitlogs_event(event_shot)
    local player = entitylist.get_local_player()

    local userid = entitylist.get_player_by_index(engine.get_player_for_user_id(event_shot:get_int("userid")))
    local attacker = entitylist.get_player_by_index(engine.get_player_for_user_id(event_shot:get_int("attacker")))

    hitlogs.remaining = event_shot:get_int("health")
    hitlogs.hgroup = hitlogs_groups[event_shot:get_int("hitgroup") + 1]
    hitlogs.hurt = event_shot:get_int("dmg_health")
	hitlogs.name = userid:get_name()

    if attacker ~= player then
        return
    end
end

function shot_event(shot_info)
	local r, g, b, a = ui.get_color("color"):r(), ui.get_color("color"):g(), ui.get_color("color"):b(), ui.get_color("color"):a()

	local text = {}
	
	if shot_info.result ~= "Hit" then
		if shot_info.result == "Spread" then
			text = {
				{font = fonts.default, text = ("Missed shot due to "), shadow = true},
				{font = fonts.default, text = ("inaccuracy"), color = color.new(r, g, b, a), shadow = true}
			}
		elseif shot_info.result == "Occlusion" then
			text = {
				{font = fonts.default, text = ("Missed shot due to "), shadow = true},
				{font = fonts.default, text = ("occlusion"), color = color.new(r, g, b, a), shadow = true}
			}
		elseif shot_info.result == "Resolver" then
			text = {
				{font = fonts.default, text = ("Missed shot due to "), shadow = true},
				{font = fonts.default, text = ("bad resolve"), color = color.new(r, g, b, a), shadow = true}
			}
		else
			text = {
				{font = fonts.default, text = ("Missed shot due to "), shadow = true},
				{font = fonts.default, text = ("unknown"), color = color.new(r, g, b, a), shadow = true}
			}
		end
	else
		text = {
			{font = fonts.default, text = ("Registered shot at "), shadow = true},
			{font = fonts.default, text = (hitlogs.name), color = color.new(r, g, b, a), shadow = true},
			{font = fonts.default, text = ("'s "), shadow = true},
			{font = fonts.default, text = (hitlogs.hgroup), color = color.new(r, g, b, a), shadow = true},
			{font = fonts.default, text = (" for "), shadow = true},
			{font = fonts.default, text = (hitlogs.hurt), color = color.new(r, g, b, a), shadow = true},
			{font = fonts.default, text = (" ("), shadow = true},
			{font = fonts.default, text = (hitlogs.remaining), color = color.new(r, g, b, a), shadow = true},
			{font = fonts.default, text = (" health remaining) [history: "), shadow = true},
			{font = fonts.default, text = (shot_info.backtrack), color = color.new(r, g, b, a), shadow = true},
			{font = fonts.default, text = ("]"), shadow = true}
		}
	end
		
    table.insert(hitlogs_list, {
        text = text,
        time = hitlogs.lifetime,
        alpha = 0,
		result = shot_info.result
    })
end

function hitlogs_paint()
    local x, y = engine.get_screen_width()/2, engine.get_screen_height()/2
    local r, g, b, a = ui.get_color("color"):r(), ui.get_color("color"):g(), ui.get_color("color"):b(), ui.get_color("color"):a()
	
	hitlogs.lifetime = ui.get_int("lifetime")

    local hitlogs_offset = 0
    for key, value in ipairs(hitlogs_list) do
        value.time = value.time - globalvars.get_frametime()

        value.alpha = animate.lerp(value.alpha, value.time <= 0 and 0.05 or 1, 0.04)

        local text_width, text_height = render.measure_multitext(value.text), render.get_text_height(fonts.default, value.text[1])

        local new_x, new_y = x - text_width/2 - 2000 + (2000 * (ui.get_int("animation") == 1 and value.alpha or 1)), y + 200 + hitlogs_offset + ui.get_int("logs offset") + 1000 - (1000 * (ui.get_int("animation") == 2 and value.alpha or 1))
		
		render.rect_filled_rounded(new_x - 11, new_y + (30 / 2) - (text_height / 2), render.measure_multitext(value.text) + 22, 26, 110, 14, color.new(22, 22, 22, 200))
		render.rect_rounded(new_x - 11, new_y + (30 / 2) - (text_height / 2), render.measure_multitext(value.text) + 22, 26, color.new(r, g, b, a), 14)
        
		render.multitext(new_x, new_y + (30 / 2) - (text_height / 2) + 5, value.text)
		
        hitlogs_offset = hitlogs_offset + 35 * value.alpha

        if value.alpha <= 0.06 or #hitlogs_list > ui.get_int("max logs") then
            table.remove(hitlogs_list, key)
        end
    end
end

events.register_event("round_prestart", function(event)
    shot_data = {}
end)

cheat.RegisterCallback("on_shot", shot_event)
cheat.RegisterCallback("on_paint", hitlogs_paint)

events.register_event("player_hurt", function(event)
    hitlogs_event(event)
end)

local function shot(info)
	console.print(info.result)
end