local font = render.setup_font("Tahoma", 12, 500, true, true , false)
local font2 = render.setup_font("Tahoma", 12, 500, true, true, false)
local screenx = engine.get_screen_width()
local screeny = engine.get_screen_height()
local name = engine.get_gamename()

ui.add_sliderint("Shuuko.lua", 0, 0)
ui.add_sliderint("Visuals", 0, 0)
ui.add_colorpicker("Accent Color")
ui.add_checkbox("Enable Watermark")
--ui.add_combobox("Head accessory", {"None", "Nimbus"})
--ui.add_colorpicker("Nimbus color")
ui.add_checkbox("Crosshair Indicators")
ui.add_sliderint("Anti Aim", 0, 0)
ui.add_combobox("Anti-Aim Presets", {"Custom", "Tank AA", "Safe Head", "Shuuko.lua"})
ui.add_checkbox("Enable Anti-Aim")
ui.add_combobox("Pitch", {"None", "Down", "Up"})
ui.add_combobox("Yaw Base", {"Backwards", "At Targets"})
ui.add_sliderint("Yaw Base Add", -180 , 180)
ui.add_combobox("Yaw Modifier", {"Disabled", "Jitter", "Spin"})
ui.add_sliderint("Yaw Modifier Add", 1, 180)

ui.add_combobox("Fake Options", {"Disabled", "Static", "Jitter"})
ui.add_sliderint("Fake Limit Right", 0, 60)
ui.add_sliderint("Fake Limit Left", 0, 60)

ui.add_checkbox("Legbreaker")
cheat.notify("Shuuko.lua Loaded")
cheat.notify("Script Version: 0. 0. 3")
ui.add_sliderint("Misc", 0, 0)
ui.add_checkbox("Filter Console")
ui.add_checkbox("Ideal Tick")
ui.add_checkbox("Killsay")
ui.add_checkbox("Clantag")
ui.add_checkbox("Hit Logs")
local switch1 = true
local random_phrases

local strings_value = 32

local labels =
{
"$",
"S",
"S|",
"S|n",
"Sh",
"Sh7",
"Shu",
"Shu7",
"Shuu",
"Shuuk",
"Shuuk0",
"Shuuko",
"Shuuko.",
"Shuuko.l",
"Shuuko.lu",
"Shuuko.lua",
"Shuuko.lua",
"Shuuko.lu",
"Shuuko.l",
"Shuuko.",
"Shuuko",
"Shuuk0",
"Shuuk",
"Shuu",
"Shu7",
"Shu",
"Sh7",
"Sh",
"S|n",
"S|",
"S",
"$"
}

local first = 0
local second = 0



local eaa = ("Enable Anti-Aim")
local pitch = ("Pitch")
local yawbase = ("Yaw Base")
local yawbaseadd = ("Yaw Base Add")
local yawmodifier = ("Yaw Modifier")
local yawmodifieradd = ("Yaw Modifier Add")
local desync = ("Fake Options")
local desync_range = ("Fake Limit Right")
local desync_range_inverted = ("Fake Limit Left")
local lby_range = ("LBY Add Right")
local lby_range_inverted = ("LBY Add Left")
local function bestaa()
    
        if ui.get_int("Anti-Aim Presets") == 0 then
            
            ui.set_bool("Antiaim.enable", ui.get_bool(eaa))
            ui.set_int("0Antiaim.pitch", ui.get_int(pitch))
            ui.set_int("0Antiaim.base_angle", ui.get_int(yawbase))
            ui.set_int("Antiaim.yaw_offset", ui.get_int(yawbaseadd))
            ui.set_int("0Antiaim.yaw", ui.get_int(yawmodifier))
            ui.set_int("0Antiaim.range", ui.get_int(yawmodifieradd))
            ui.set_int("0Antiaim.desync", ui.get_int(desync))
            ui.set_int("0Antiaim.desync_range", ui.get_int(desync_range))
            ui.set_int("0Antiaim.inverted_desync_range", ui.get_int(desync_range_inverted))
            
        end
        if ui.get_int("Anti-Aim Presets") == 1 then
            ui.set_bool("Antiaim.enable", true)
            ui.set_int("0Antiaim.base_angle", 0)
            ui.set_int("0Antiaim.yaw", 1)
            ui.set_int("Antiaim.yaw_offset", -12)
            ui.set_int("0Antiaim.desync", 2)
            ui.set_int("0Antiaim.range", math.random(66, 75))
            ui.set_int("0Antiaim.desync_range", 58)
            ui.set_int("0Antiaim.inverted_desync_range", 60)
        end
        if ui.get_int("Anti-Aim Presets") == 2 then
            ui.set_bool("Antiaim.enable", true)
            ui.set_int("0Antiaim.pitch", 1)
            ui.set_int("0Antiaim.base_angle", 1)
            ui.set_int("Antiaim.yaw_offset", -4)
            ui.set_int("0Antiaim.yaw", 0)
            ui.set_int("0Antiaim.desync", 1)
            ui.set_int("0Antiaim.desync_range", 60)
            ui.set_int("0Antiaim.inverted_desync_range", 60)
            
        end
        if ui.get_int("Anti-Aim Presets") == 3 then
            ui.set_bool("Antiaim.enable", ui.get_bool(eaa))
            ui.set_int("0Antiaim.pitch", 1)
            ui.set_int("0Antiaim.base_angle", 0)
            ui.set_int("Antiaim.yaw_offset", -12)
            ui.set_int("0Antiaim.yaw", 1)
            ui.set_int("0Antiaim.range", math.random(20, 33))
            ui.set_int("0Antiaim.desync", 2)
            ui.set_int("0Antiaim.desync_range", 47)
            ui.set_int("0Antiaim.inverted_desync_range", 50)
            
        end
    
end

local function watermark()
local ping = globalvars.get_ping()
local systemtime = globalvars.get_time()
local x, y = engine.get_screen_width(),engine.get_screen_height()
local fps = math.floor(1 / globalvars.get_frametime())
local text = "shuuko".." - "..name.." - ".."fps:"..fps.." - ".."delay:"..ping.."ms".." - "..systemtime
local textsize = render.get_text_width(font,text)

if ui.get_bool("Enable Watermark") then
    render.rect_filled(x - textsize -15,12,textsize +10, 16, color.new(0,0,0,120))
    render.rect_filled(x - textsize -15,12,textsize +10, 2, ui.get_color("Accent Color"))
    render.text(font, x - textsize - 10,14,color.new(255,255,255,255), text)
end
end


local function idealtick()
    if ui.get_bool("Ideal Tick") then
        if ui.get_keybind_state(keybinds.automatic_peek) then
            ui.set_bool("Antiaim.freestand", true)
        else
            ui.set_bool("Antiaim.freestand", false)
        end  
    end
end





--[[local function halo()
    local local_player = entitylist.get_local_player()
    local is_alive = local_player:is_alive()
    if ui.get_int("Head accessory") == 1 and is_alive and ui.get_keybind_state("misc.third_person_key")then
        
        local hanim = math.floor(math.sin(globalvars.get_realtime() * 5) * 127 + 128)
        local heads = entitylist.get_local_player():get_player_hitbox_pos(0)
        heads.z = heads.z + 10
        local rfoot = entitylist.get_local_player():get_player_hitbox_pos(11)
        local headscreen = render.world_to_screen(heads)




        render.circle_3d(heads, 5, ui.get_color("Nimbus color"))

    end
end
--]]

local function trashtalk()
    if ui.get_bool("Killsay") then
        events.register_event("player_death", function(e)
            local attacker = e:get_int("attacker")
            local attacker_to_player = engine.get_player_for_user_id(attacker)

            local lp_idx = engine.get_local_player_index()

            if attacker_to_player == lp_idx then
            phrases = {"ало придурок тебя Рейвтрип хснул",
                        "смачно соснул хуйца",
                        "куда летишь",
                        "ало это из мчс у вас мать сгорела",
                        "тупее тебя может быть только твой отец который выебал твою больную мать",
                        "я матери твоей хребет пальцем выбил",
                        "МАМАШУ ТВОЮ В РОТ ОТЬЕБАЛ, И ШПАГОЙ ЕЕ ПИЗДУ ЗАКОЛОЛ.",
                        "ебланище как те мой членяка на вкус",
                        "долбаеб тебе в твою хижину 2джи провели?",
                        "мама поплавать в тазике позвала?",
                        "ты походу на член своего отца пересмотрел",
                        "я твою мать забайтил на минет горловой",
                        "тебе мой хуй в горло не влазит ты что забыл ?",
                        "пропиши /repair и имя твоей матери",
                        "выйди нахуй отсюда пока я тебе шею не свернул",
                        "слишком сочный для Shuuko.technologies"}
                    random_phrases = math.random(1, 15)
                
                    console.execute_client_cmd("say " .. phrases[random_phrases])
                
            end
        end)
    end
end

local function fc()
    if ui.get_bool("Filter Console") then
        console.set_int("con_filter_enable", 2)
        console.set_string("con_filter_text", "[rawetrip]")
    else
        console.set_int("con_filter_enable", 0)
        console.set_string("con_filter_text", "")
    end
end


local function indicators()
    local local_player = entitylist.get_local_player()
    local is_alive = local_player:is_alive()
    local connected = engine.is_connected()
    if ui.get_bool("Crosshair Indicators") and connected and is_alive then
        offset = 30
        
        if ui.get_keybind_state(keybinds.flip_desync) then
            render.text(font, screenx/2 + 4, screeny/2 + 20, ui.get_color("Accent Color"), "o.lua")
            render.text(font, screenx/2 - 24, screeny/2 + 20, color.new(255, 255, 255, 255), "shuuk")
        end
        if not ui.get_keybind_state(keybinds.flip_desync) then
            render.text(font, screenx/2 + 4, screeny/2 + 20, color.new(255, 255, 255, 255), "o.lua")
            render.text(font, screenx/2 - 24, screeny/2 + 20, ui.get_color("Accent Color"), "shuuk")
        end
        if ui.get_keybind_state(keybinds.double_tap) then
            render.text(font2, screenx/2 - 22, screeny/2 + offset, color.new(66, 245, 93, 255), "doubletap")
            offset = offset + 10
        end
        if ui.get_keybind_state(keybinds.hide_shots) then
            render.text(font2, screenx/2 - 22, screeny/2 + offset, color.new(245, 69, 66, 255), "hideshots")
            offset = offset + 10
        end
        if ui.get_keybind_state(keybinds.damage_override) then
            render.text(font2, screenx/2 - 34, screeny/2 + offset, color.new(93, 66, 245, 255), "damage override")
            offset = offset + 10
        end
        if ui.get_keybind_state(keybinds.body_aim) then
            render.text(font2, screenx/2 - 25, screeny/2 + offset, color.new(50, 86, 168, 255), "force body")
            offset = offset + 10
        end
        if ui.get_keybind_state(keybinds.fakeduck) then
            render.text(font2, screenx/2 - 22, screeny/2 + offset, color.new(93, 66, 245, 255), "fakeduck")
            offset = offset + 10
        end
        if ui.get_keybind_state(keybinds.safe_points) then
            render.text(font2, screenx/2 - 22, screeny/2 + offset, color.new(255, 255, 255, 255), "safe points")
            offset = offset + 10
        end
        if ui.get_keybind_state(keybinds.automatic_peek) then
            render.text(font2, screenx/2 - 22, screeny/2 + offset, color.new(255, 255, 255, 255), "autopeek")
            offset = offset + 10
        end
    end
end


local function menu_preview()
    local systemtime = globalvars.get_time()
    local menuisopen = globalvars.is_open_menu()
    local menux = globalvars.get_menu_pos_x()
    local menuy = globalvars.get_menu_pos_y()
    if menuisopen then
        render.rect_filled(menux + 10, menuy - 25, 630 + 50, 20, color.new(0,0,0,160))
        render.text(font, menux + 15, menuy - 20, color.new(255, 255, 255, 255), "Shuuko.lua | Welcome back, bro!")
        render.text(font, menux + 645, menuy - 20, color.new(255, 255, 255, 255), systemtime)
        render.rect_filled(menux + 10, menuy - 25, 630 + 50, 2, ui.get_color("Accent Color"))
    end
end

local function clantag()
    if first < globalvars.get_tickcount() then   
         second = second + 1

        if second > strings_value then
            second = 0
        end
        if ui.get_bool("Clantag") then
            engine.set_clantag(labels[second])
        else
            engine.set_clantag("")
        end
        first = globalvars.get_tickcount() + 18

    end

end

local function legbreaker()
    local local_player = entitylist.get_local_player()
    local is_alive = local_player:is_alive()
    if ui.get_bool("Legbreaker") and cmd.get_send_packet() == true then
        if is_alive == true then
            if switch1 == true then
                switch1 = false
            else
                switch1 = true
            end
            if switch1 then
                ui.set_int("Misc.leg_movement", 1)
            else
                ui.set_int("Misc.leg_movement", 2)
            end
        else
            ui.set_int("Misc.leg_movement", 0)
        end
    end
end


local notify, notify_list = {}, {}

local lerp = function(a, b, percentage)return a + (b - a) * percentage;end
local get_screen_size = function() return engine.get_screen_width(), engine.get_screen_height() end

local font = render.setup_font("Verdana", 12, 400, true, false, false)

notify.run = function(text, ms, color) return table.insert(notify_list, 1, {text = text, ms = ms, alpha = 0, asx = -10, frametime = globalvars.get_frametime(), color = color}) end




notify.on_paint = function()
    local height_offset = 23

    local sx, sy = get_screen_size()
    sy = sy - 300

    for c_name, c_data in pairs(notify_list) do
        c_data.ms = c_data.ms - globalvars.get_frametime()
        c_data.alpha = lerp(c_data.alpha, c_data.ms <= 0 and 0 or 1, globalvars.get_frametime() * 8)
        c_data.asx = lerp(c_data.asx, c_data.ms <= 0 and 10 or 0, globalvars.get_frametime() * 8)
        c_data.color = c_data.color == nil and {255, 255, 255} or c_data.color

        render.text(font, ((sx / 2) - (render.get_text_width(font, c_data.text) / 2)) + 12 * c_data.asx, sy + height_offset, color.new(c_data.color[1], c_data.color[2], c_data.color[3], c_data.alpha*255), c_data.text)

        height_offset = height_offset + 13 * c_data.alpha
    end
end

local function shot_info(e)
    if ui.get_bool("Hit Logs") then
        if e.result == "Hit" then
            notify.run(""..e.target_name.." for "..e.server_damage.."("..e.client_damage..")", 5, {255, 0, 0})
            
        end
    end
end

cheat.RegisterCallback("on_shot", shot_info)

local function paint()
watermark();
--halo();
menu_preview();
indicators();
notify.on_paint();
end
cheat.RegisterCallback("on_paint", paint)
local function createmove()
fc();
legbreaker();
bestaa();
idealtick();
clantag();
trashtalk();
end
cheat.RegisterCallback("on_createmove", createmove)