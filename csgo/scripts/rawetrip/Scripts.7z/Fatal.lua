local font = render.setup_font("Verdana", 12, 500, true, true, false)
local font_med = render.setup_font("Verdana", 14, 500, true, true, false)
local font_netgraph = render.setup_font("Verdana", 16, 400, true, true, false)
local font_big = render.setup_font("Verdana", 24, 500, true, true, false)
local font_small = render.setup_font("Verdana", 10, 400, true, true, false)
local font_small_calibri = render.setup_font("Calibri", 16, 200, true, false, false)

cheat.notify("Fatal Lua loaded. Welcome back, player! ")

ui.add_sliderint("Fatal", 0, 0)
ui.add_checkbox("Enable Watermark")
ui.add_checkbox("Enable Indicators")
ui.add_checkbox("Enable Holo-Panel")
ui.add_checkbox("Enable Keybinds")
ui.add_sliderint("x", 0, engine.get_screen_width() - 200)
ui.add_sliderint("y", 0, engine.get_screen_height() - 25)
ui.add_combobox("Keybinds style", {"Static", "Rainbow"})
ui.add_checkbox("Enable halo")
--ui.add_colorpicker("holopanelcolor")
ui.add_checkbox("Enable Aniaim Fucker")
ui.add_combobox("Fucker type", {"Force slide", "Backward slide"})
ui.add_checkbox("Enable Viewmodel in-scope")
ui.add_combobox("Menu bar style", {"Short", "float", "Long"})
ui.add_checkbox("Enable Line on top")
ui.add_checkbox("Enable netgraph")
ui.add_sliderint("X netgraph", 0, engine.get_screen_width() - 110)
ui.add_sliderint("Y netgraph", 0, engine.get_screen_height() - 19)

local swtich = true

local function lerp(start, _end, time, do_extraanim) if (not do_extraanim and math.floor(start) == _end) then return _end end; time = globalvars.get_frametime() * (time * 175); if time < 0 then time = 0.01 elseif time > 1 then time = 1 end; return (_end - start) * time + start end
local anim = 0
local x_wat = 0

local function Legbreak()
    local local_player = entitylist.get_local_player()
    local is_alive = local_player:is_alive()
    local slidebreak = 0
    if ui.get_int("Fucker type") == 0 then
    slidebreak = 2
    end
    if ui.get_int("Fucker type") == 1 then
    slidebreak = 1
    end

    
    if ui.get_bool("Enable Aniaim Fucker") and cmd.get_send_packet() == true then
        if is_alive == true then
            if swtich then
                swtich = false
            else
                swtich = true
            end
            if swtich then
                ui.set_int("Misc.leg_movement", 0)
            else
                ui.set_int("Misc.leg_movement", slidebreak)
            end
        else
            ui.set_int("Misc.leg_movement", 0)
        end  
    end
end
cheat.RegisterCallback("on_createmove", Legbreak)

local pos = { x = engine.get_screen_width() / 2 + 130, y = engine.get_screen_height() / 2 - 90}


local function paint()
 	local y = engine.get_screen_height()
	local x = engine.get_screen_width()
	local xmen = globalvars.get_menu_pos_x()
	local ymen = globalvars.get_menu_pos_y()
	local menu_opened = globalvars.is_open_menu()
	local fps = globalvars.get_framerate()	
	
	local rb = math.floor(math.sin(globalvars.get_realtime() * 2) * 127 + 128)
    	local gb =  math.floor(math.sin(globalvars.get_realtime() * 2 + 2) * 127 + 128)
    	local bb = math.floor(math.sin(globalvars.get_realtime() * 2 + 4) * 127 + 128)
    	
    	
    	local rbb = math.floor(math.sin(globalvars.get_realtime() * 3) * 127 + 128)
    	local gbb =  math.floor(math.sin(globalvars.get_realtime() * 3 + 2) * 127 + 128)
    	local bbb = math.floor(math.sin(globalvars.get_realtime() * 3 + 4) * 127 + 128)
 

	
	offset = 10
        	if menu_opened == true then
        	
        	anim = lerp(anim, 0, 0.05, false)
        	
        		if ui.get_int("Menu bar style") == 0 then
    	render.rect_filled(xmen, ymen - 30 + anim, 160 + 60, 30, color.new(0,0,0,120))
    	render.text(font, xmen + 10, ymen - 20 + anim, color.new(255, 255, 255, 255), "Fatal Lua" .. "     " .. "Fps: " .. tostring(fps))
    	render.gradient(xmen, ymen - 30 + anim, 160 + 60, 2, color.new(rb,gb,bb,255), color.new(rbb,gbb,bbb,255), horizontal)
    	end
    	
    	if ui.get_int("Menu bar style") == 1 then
    	local upanim = math.floor(math.sin(globalvars.get_realtime() * 5) * 30 + 30)
    	
    	local idyas = render.get_text_width(font_big, "Fatal Lua")
    	local fpsize = render.get_text_width(font_med, "Fps: " .. tostring(fps))
    	render.rect_filled(xmen - 250, ymen - 60 - 60  + upanim, 160 + 60, 30, color.new(0,0,0,120))
    	render.text(font_big, xmen + 7 - 250, ymen - 56 - 60  + upanim, color.new(255, 255, 255, 255), "Fatal lua")
    	render.text(font_med, xmen + 7 - 250 + 220 - fpsize - 15, ymen - 51 - 60  + upanim, color.new(255, 255, 255, 255), "Fps: " .. tostring(fps))
    	render.gradient(xmen - 250, ymen - 60 - 60  + upanim, 160 + 60, 2, color.new(rb,gb,bb,255), color.new(rbb,gbb,bbb,255), horizontal)
    	render.line(xmen - 250 + 220, ymen - 60 - 60 + upanim, xmen, ymen, color.new(rbb,gbb,bbb,255))
end

    	if ui.get_int("Menu bar style") == 2 then
    	render.rect_filled_rounded(xmen, ymen - 26 + anim, 700, 22, 50, 3, color.new(0,0,0,150))
    	
    	local idys = render.get_text_width(font_small_calibri, "Fatal-Lua")
    	render.text(font_small_calibri, xmen + 7, ymen - 23 + anim, color.new(242, 107, 255, 255), "Fatal")
    	render.text(font_small_calibri, xmen + 6, ymen - 22 + anim, color.new(242, 107, 255, 255), "Fatal")
    	render.text(font_small_calibri, xmen + 6, ymen - 23 + anim, color.new(255, 255, 255, 255), "Fatal")
    	render.text(font_small_calibri, xmen + idys + 8, ymen - 24 + anim, color.new(255, 255, 255, 255), "|")
    	render.text(font_small_calibri, xmen + idys + 8 + 8, ymen - 23 + anim, color.new(255, 255, 255, 255), "Welcome back, " .. globalvars.get_winuser())
    	render.text(font_small_calibri, xmen + 750 - 53 - 50, ymen - 23 + anim, color.new(255, 255, 255, 255), globalvars.get_time())
end

   	else
   	anim = lerp(anim, 25, 0.05, false)
end
   	
if ui.get_bool("Enable Line on top") then
render.gradient(0, 0, engine.get_screen_width(), 2, color.new(rb,gb,bb), color.new(rbb,gbb,bbb))
end

   	
if ui.get_bool("Enable Viewmodel in-scope") then
            if ui.get_keybind_state( "misc.third_person_key" ) then
                console.set_int( "fov_cs_debug", 0 )
            else
                console.set_int( "fov_cs_debug", 90 )
		 end
else
console.set_int( "fov_cs_debug", 0 )
end
   	
   	
   	   if ui.get_bool("Enable Keybinds") then 
   local x_pos = ui.get_int("x")
   local y_pos = ui.get_int("y")
   local offsett = 15  
   local hsmode = ui.get_keybind_mode(keybinds.hide_shots)
   local dtmode = ui.get_keybind_mode(keybinds.double_tap)
   local apmode = ui.get_keybind_mode(keybinds.automatic_peek)
   local spmode = ui.get_keybind_mode(keybinds.safe_points)
   local aamode = ui.get_keybind_mode(keybinds.flip_desync)
   local baimode = ui.get_keybind_mode(keybinds.body_aim)
   local swmode = ui.get_keybind_mode(keybinds.slowwalk)
   local fdmode = ui.get_keybind_mode(keybinds.fakeduck)
   local ejmode = ui.get_keybind_mode(keybinds.edge_jump)
   local dmgmode = ui.get_keybind_mode(keybinds.damage_override)
   if ui.get_int("Keybinds style") == 0 then
render.gradient(x_pos, y_pos, 60, 2, color.new(0,0,0,0), color.new(255,255,255))
render.gradient(x_pos + 60, y_pos, 60, 2, color.new(255,255,255), color.new(0,0,0,0))
end
if ui.get_int("Keybinds style") == 1 then
render.triplegradient(x_pos, y_pos, 120, 2, color.new(1,212,255,255), color.new(207,32,192,255), color.new(255,248,1,255), 0)
end
render.rect_filled(x_pos, y_pos + 2, 120, 15, color.new(0,0,0, 180))
render.text(font, x_pos + 40 - 3, y_pos + 3, color.new(255,255,255), "keybinds ")
if (ui.get_keybind_state(keybinds.double_tap)) then
render.text(font, x_pos + 2, y_pos + 3 + offsett, color.new(255,255,255), "Double Tap ")
render.text(font, x_pos + 110 - 5 - 5 - 2,y_pos + 3 + offsett, color.new(255,255,255), "[" .. "on" .. "]")
offsett = offsett + 15
end
if (ui.get_keybind_state(keybinds.hide_shots)) then
render.text(font, x_pos + 2, y_pos + 3 + offsett, color.new(255,255,255), "On shot Anti-Aim ")
render.text(font, x_pos + 110 - 5 - 5 - 2, y_pos + 3 + offsett, color.new(255,255,255), "[" .. "on" .. "]")
offsett = offsett + 15
end

if (ui.get_keybind_state(keybinds.flip_desync)) then
render.text(font, x_pos + 2, y_pos + 3 + offsett, color.new(255,255,255), "Desync Inverter ")
render.text(font, x_pos + 110 - 5 - 5 - 2, y_pos + 3 + offsett, color.new(255,255,255), "[" .. "on" .. "]")
offsett = offsett + 15
end

if (ui.get_keybind_state(keybinds.body_aim)) then
render.text(font, x_pos + 2, y_pos + 3 + offsett, color.new(255,255,255), "Force Baim ")
render.text(font, x_pos + 110 - 5 - 5 - 2, y_pos + 3 + offsett, color.new(255,255,255), "[" .. "on" .. "]")
offsett = offsett + 15
end

if (ui.get_keybind_state(keybinds.slowwalk)) then
render.text(font, x_pos + 2, y_pos + 3 + offsett, color.new(255,255,255), "Slow Motion ")
render.text(font, x_pos + 110 - 5 - 5 - 2, y_pos + 3 + offsett, color.new(255,255,255), "[" .. "on" .. "]")
offsett = offsett + 15
end

if (ui.get_keybind_state(keybinds.fakeduck)) then
render.text(font, x_pos + 2, y_pos + 3 + offsett, color.new(255,255,255), "Fake Duck ")
render.text(font, x_pos + 110 - 5 - 5 - 2, y_pos + 3 + offsett, color.new(255,255,255), "[" .. "on" .. "]")
offsett = offsett + 15
end

if (ui.get_keybind_state(keybinds.edge_jump)) then
render.text(font, x_pos + 2, y_pos + 3 + offsett, color.new(255,255,255), "Edge Jump ")
render.text(font, x_pos + 110 - 5 - 5 - 2, y_pos + 3 + offsett, color.new(255,255,255), "[" .. "on" .. "]")
offsett = offsett + 15
end

if (ui.get_keybind_state(keybinds.automatic_peek)) then
render.text(font, x_pos + 2, y_pos + 3 + offsett, color.new(255,255,255), "Quick Peek Assist ")
render.text(font, x_pos + 110 - 5 - 5 - 2, y_pos + 3 + offsett, color.new(255,255,255), "[" .. "on" .. "]")
offsett = offsett + 15
end

if (ui.get_keybind_state(keybinds.damage_override)) then
render.text(font, x_pos + 2, y_pos + 3 + offsett, color.new(255,255,255), "Damage Override ")
render.text(font, x_pos + 110 - 5 - 5 - 2, y_pos + 3 + offsett, color.new(255,255,255), "[" .. "on" .. "]")
offsett = offsett + 15
end

if (ui.get_keybind_state(keybinds.safe_points)) then
render.text(font, x_pos + 2, y_pos + 3 + offsett, color.new(255,255,255), "Force Safe Point ")
render.text(font, x_pos + 110 - 5 - 5 - 2, y_pos + 3 + offsett, color.new(255,255,255), "[" .. "on" .. "]")
offsett = offsett + 15
end
end

   	
   	if menu_opened == true then
   		x_wat = lerp(x_wat, 205, 0.05, false)
   	else
   		x_wat = lerp(x_wat, 0, 0.05, false)
   	end
   	
   	
 if ui.get_bool("Enable Watermark") then
local screen_w = engine.get_screen_width()
local screen_h = engine.get_screen_height()
local datetime = globalvars.get_time()
local xx, yy= engine.get_screen_width()/2,engine.get_screen_height()/2
local sundwat = render.get_text_width(font, "Fatal | " .. "Rawetrip" .. " | " .. globalvars.get_ping() .. "ms" .. " |  " .. datetime)
render.rect_filled(screen_w - sundwat - 10 + x_wat, 10, sundwat + 4, 17, color.new(0,0,0,120))
render.rect_filled(screen_w - sundwat - 10 + x_wat, 10, sundwat + 4, 2, color.new(255,255,255,255))
render.gradient(screen_w - sundwat - 10 + x_wat, 10, sundwat + 4, 2, color.new(rb,gb,bb,255), color.new(rbb,gbb,bbb,255))
render.text(font, screen_w - sundwat - 10 + 2 + x_wat, 13, color.new(255,255,255,255), "DJZX GK | " .. "Rawetrip" .. " | " .. globalvars.get_ping() .. "ms" .. " |  " .. datetime)
--if ui.get_int("Watermark mode") == 1 then
if(ui.get_keybind_state(keybinds.double_tap)) then
local ioind = globalvars.get_frametime()*1000
render.rect_filled(screen_w - 86 + x_wat, 30, 80, 17, color.new(0,0,0,120))
render.gradient(screen_w - 59 + x_wat, 34, 50 - math.ceil(ioind)*4, 8, color.new(255,255,255,255), color.new(0,0,0,0))

render.rect_filled(screen_w - 86 + x_wat, 45, 80, 2, color.new(255,255,255,255))
--render.rect_filled(screen_w - 125 + x_wat, 35, 50 , 8, color.new(255,0,0,120))
render.text(font, screen_w - 83 + x_wat, 31, color.new(255,255,255,255), "IO |")
end

if(ui.get_keybind_state(keybinds.hide_shots)) then
local ioind = globalvars.get_frametime()*1000
render.rect_filled(screen_w - 86 + x_wat, 30, 80, 17, color.new(0,0,0,120))
render.gradient(screen_w - 59 + x_wat, 34, 50 - math.ceil(ioind)*4, 8, color.new(255,255,255,255), color.new(0,0,0,0))
render.rect_filled(screen_w - 86 + x_wat, 45, 80, 2, color.new(255,255,255,255))
--render.rect_filled(screen_w - 125 + x_wat, 35, 50 , 8, color.new(255,0,0,120))
render.text(font, screen_w - 83 + x_wat, 31, color.new(255,255,255,255), "IO |")
end

if not (ui.get_keybind_state(keybinds.double_tap)) and not (ui.get_keybind_state(keybinds.hide_shots)) then
local ioind = globalvars.get_frametime()*1000
render.rect_filled(screen_w - 86 + x_wat, 30, 80, 17, color.new(0,0,0,120))
render.gradient(screen_w - 59 + x_wat, 34, 50 - math.ceil(ioind)*4, 8, color.new(255,255,255,255), color.new(0,0,0,0))
render.rect_filled(screen_w - 86 + x_wat, 45, 80, 2, color.new(255,255,255,255))
--render.rect_filled(screen_w - 125 + x_wat, 35, 50 , 8, color.new(255,0,0,120))
render.text(font, screen_w - 83 + x_wat, 31, color.new(255,255,255,255), "FL |")
render.gradient(screen_w - 86 - 14 - 10 + x_wat, 30, 20, 17, color.new(0,0,0,200), color.new(0,0,0,0))
render.gradient(screen_w - 86 - 14 - 20 - 10 + x_wat, 30, 20, 17, color.new(0,0,0,0), color.new(0,0,0,200))

render.gradient(screen_w - 86 - 14 - 10 + x_wat, 45, 20, 2, color.new(255,255,255,255), color.new(0,0,0,0))
render.gradient(screen_w - 86 - 14 - 20 - 10 + x_wat, 45, 20, 2, color.new(0,0,0,0), color.new(255,255,255,255))

render.text(font, screen_w - 86 - 14 - 7 - 10 + x_wat, 31, color.new(255,255,255,255), "FL")
local realtime_fade = math.floor(math.sin(globalvars.get_realtime() * 5) * 127 + 128)
render.text(font, screen_w - 86 - 14 - 7 - 10 + x_wat, 31, color.new(255,100,100,realtime_fade), "FL")

end

end
--end

   	
    if ui.get_bool("Enable Indicators") then
        if not engine.is_in_game() then return end
    if entitylist.get_local_player():get_health() == 0 then return end

    	render.text(font, x/2 + 10, y/2 + 20, color.new(109, 191, 191, 255), "Fatal")
    	
    	if(ui.get_keybind_state(keybinds.flip_desync)) then
    	render.text(font, x/2 + 10, y/2 + 20 + offset, color.new(255, 74, 74, 255), "Inverted")
 	offset = offset + 10
    	else
    	render.text(font, x/2 + 10, y/2 + 20 + offset, color.new(255, 74, 74, 255), "Normal")
    	offset = offset + 10
    	end
    	
    	if(ui.get_keybind_state(keybinds.double_tap)) then   

    	render.text(font, x/2 + 10, y/2 + 20 + offset, color.new(0, 255, 42, 255), "DT")
    	offset = offset + 10
    	end
    	
    	if(ui.get_keybind_state(keybinds.hide_shots)) then    	
    	render.text(font, x/2 + 10, y/2 + 20 + offset, color.new(179, 255, 0, 255), "HS")
    	offset = offset + 10
    	end

    	if(ui.get_keybind_state(keybinds.damage_override)) then    	
    	render.text(font, x/2 + 10, y/2 + 20 + offset, color.new(102, 0, 255, 255), "DMG")
    	offset = offset + 10
    	end
    	
    	if(ui.get_keybind_state(keybinds.body_aim)) then    	
    	render.text(font, x/2 + 10, y/2 + 20 + offset, color.new(0, 94, 255, 255), "FORCE BODY")
    	offset = offset + 10
    	end
   end
   
if not (ui.get_keybind_state(keybinds.thirdperson)) then return end
if not engine.is_in_game() then return end
    if entitylist.get_local_player():get_health() == 0 then return end
    
       	if ui.get_bool("Enable netgraph") then
   	local fps = math.floor(1 / globalvars.get_frametime())
   	local pinguha = globalvars.get_ping()
   	local fpsek = render.get_text_width(font_netgraph, tostring(fps))
   	local timereal = globalvars.get_time()
   	local ping2 = math.floor(pinguha * 10000 / 19.5)
   	local chokek = render.get_text_width(font_netgraph, "Choke: " .. tostring(choke))
   	local timeek = render.get_text_width(font_netgraph, "Time: " .. timereal)
   	local x_pos = ui.get_int("X netgraph")
   	local y_pos = ui.get_int("Y netgraph")
    local local_player = entitylist.get_local_player()
    local velocity = local_player:get_velocity()
    local speed = velocity:length_2d()   	
   	local colorfps = color.new(0, 255, 255)
   	if fps < 60 then
   	colorfps = color.new(255, 125, 95)
   	end
   	
   	local colorping = color.new(0, 255, 255)
   	if pinguha > 80 then
   	colorping = color.new(255, 125, 95)
   	end
   	
     local alpha_fade = math.floor(math.sin(globalvars.get_realtime() * 5) * 127 + 128)
   	
   	render.text(font_netgraph, x_pos, y_pos, colorfps, "Fps: " .. tostring(fps))
   	render.text(font_netgraph, x_pos + fpsek + 50, y_pos, colorping, "Ping: " .. tostring(pinguha) .. "ms")
   	render.text(font_netgraph, x_pos, y_pos + 20, color.new(255,255,255), "Time: " .. timereal)
   	render.text(font_netgraph, x_pos + timeek + 20, y_pos + 20, color.new(255,255,255), "Vel: " .. math.ceil(speed) .. " u/s")

   	render.text(font_netgraph, x_pos, y_pos + 40, color.new(255,255,255), "Ver: 2129")
   	render.text(font_med, x_pos + 20, y_pos - 20, color.new(255,255,255,alpha_fade), "Clock Syncing")
   	--render.text(font_med, x_pos + 20 , y_pos + 60, color.new(255,255,255,alpha_fade), "exploit: disabled")
   	--render.circle(x_pos + 7, y_pos - 13, 50, 6, color.new(255,255,255, 60))
   	render.circle(x_pos + 7, y_pos - 13, 50, 5, color.new(255,255,255))
   	--render.text(font_netgraph, x_pos + 63, y_pos - 50, color.new(255,255,0,255), "!")
   	render.line(x_pos + 7, y_pos - 13, x_pos + 12, y_pos - 13, color.new(255,255,255))
   	render.line(x_pos + 7, y_pos - 13, x_pos + 10, y_pos - 18, color.new(255,255,255))
   	--render.line(x_pos + 56, y_pos - 33, x_pos + 66, y_pos - 55, color.new(255,201,95))
   	--render.line(x_pos + 66, y_pos - 55, x_pos + 76, y_pos - 32, color.new(255,201,95))
   	--render.line(x_pos + 56, y_pos - 33, x_pos + 76, y_pos - 33, color.new(255,201,95))

   	--render.line(x_pos + 55, y_pos - 33, x_pos + 65, y_pos - 55, color.new(255,201,95))
   	--render.line(x_pos + 65, y_pos - 55, x_pos + 75, y_pos - 32, color.new(255,201,95))
   	--render.line(x_pos + 55, y_pos - 33, x_pos + 75, y_pos - 33, color.new(255,201,95))
   


   	end

    
--local holo_color = ui.get_color("holopanelcolor")
   local hp = entitylist.get_local_player():get_health()
    local origin = entitylist.get_local_player():get_absorigin()
    origin.z, origin.y = origin.z + 5, origin.y + 10
    local screen = render.world_to_screen(entitylist.get_local_player():get_absorigin())
    
      local originline = entitylist.get_local_player():get_absorigin()
      originline.z = originline.z + 35
      local screens = render.world_to_screen(originline)
          
      local headstart = entitylist.get_local_player():get_player_hitbox_pos(15)
      local screend = render.world_to_screen(headstart)
      
      local handstart = entitylist.get_local_player():get_player_hitbox_pos(18)
      local screendd = render.world_to_screen(handstart)

		            local pos_hand = entitylist.get_local_player():get_player_bone_pos(48)
            local screenan = render.world_to_screen(pos_hand)
            screenan.x, screenan.y = screenan.x + 130, screenan.y - 90 -- correction

            local smooth = {
                x = lerp(pos.x, screenan.x, 0.05),
                y = lerp(pos.y, screenan.y, 0.05),
            }

   pos.x, pos.y = smooth.x, smooth.y

    if x == 0 then
    	end
    	    	
		if ui.get_bool("Enable Holo-Panel") then 
		
		local flvalue = ui.get_int("Antiaim.fake_lag_limit")
		
render.rect_filled_rounded(pos.x + 100, pos.y, 137, 65, 50, 5, color.new(0,0,0, 120) )
render.triplegradient(pos.x + 100, pos.y, 138, 3,color.new(2,253,242,255), color.new(242,5,250,255), color.new(255,240,2,255))


local realtime_fade = math.floor(math.sin(globalvars.get_realtime() * 5) * 127 + 128)
local rand = math.random(100, 140)
local realtime_faded = math.floor(math.sin(globalvars.get_realtime() * 2) * rand + rand)
local circle_fade = math.floor(math.sin(globalvars.get_realtime() * 6) * 2 + 2)

render.arc(pos.x + 220, pos.y + 20, 10, 11, -90, 360, color.new(120,120,120, 120))
render.arc(pos.x + 220, pos.y + 20, 10, 11, -90, 60 + realtime_faded, color.new(255,255,255, realtime_fade))
render.line(screenan.x - 130, screenan.y + 90, pos.x + 100, pos.y, color.new(255, 255, 255))
render.circle_filled(screenan.x - 130, screenan.y + 90, 50, 4, color.new(255,255,255,255))
render.circle_filled(pos.x + 100, pos.y, 50, 2, color.new(255,255,255,255))
render.circle(screenan.x - 130, screenan.y + 90, 50, 4 + circle_fade, color.new(255,255,255,255))
render.text(font_small, pos.x + 104, pos.y + 8, color.new(255,255,255), 'ANTI-AIMBOT PANEL')
local rechdt = globalvars.get_dt_recharging()


if(ui.get_keybind_state(keybinds.hide_shots)) or (ui.get_keybind_state(keybinds.double_tap)) then
render.text(font, pos.x + 104 + 5, pos.y + 20, color.new(255,255,255), "FL: 0")
render.gradient(pos.x + 104, pos.y + 26, math.floor(2), math.floor(3), color.new(255,0,0,255), color.new(0,0,0,0), 1)
render.gradient(pos.x + 104, pos.y + 22, math.floor(2), math.floor(3), color.new(0,0,0,0), color.new(255,0,0,255), 1)
render.rect_filled(pos.x + 104, pos.y + 25, math.floor(2), math.floor(1), color.new(255,0,0, 255))

end

if not (ui.get_keybind_state(keybinds.hide_shots)) and not (ui.get_keybind_state(keybinds.double_tap)) then
render.text(font, pos.x + 104 + 5, pos.y + 20, color.new(255,255,255), "FL: " .. flvalue)
render.gradient(pos.x + 104, pos.y + 26, math.floor(2), math.floor(3), color.new(0,255,0,255), color.new(0,0,0,0), 1)
render.gradient(pos.x + 104, pos.y + 22, math.floor(2), math.floor(3), color.new(0,0,0,0), color.new(0,255,0,255), 1)
render.rect_filled(pos.x + 104, pos.y + 25, math.floor(2), math.floor(1), color.new(0,255,0, 255))
end

if(ui.get_keybind_state(keybinds.flip_desync)) then
	render.text(font, pos.x + 104 + 45, pos.y + 20, color.new(255,255,255), 'SIDE: <-')
else
	render.text(font, pos.x + 104 + 45, pos.y + 20, color.new(255,255,255), 'SIDE: ->')
end

			if (ui.get_keybind_state(keybinds.double_tap)) then
render.text(font_med, pos.x + 104 + 5, pos.y + 45, color.new(255,255,255,255), 'Exploit: DT')
render.gradient(pos.x + 104, pos.y + 54, math.floor(2), math.floor(3), color.new(0,255,0,255), color.new(0,0,0,0), 1)
render.gradient(pos.x + 104, pos.y + 50, math.floor(2), math.floor(3), color.new(0,0,0,0), color.new(0,255,0,255), 1)
render.rect_filled(pos.x + 104, pos.y + 53, math.floor(2), math.floor(1), color.new(0,255,0, 255))

			end
			if (ui.get_keybind_state(keybinds.hide_shots)) and not (ui.get_keybind_state(keybinds.double_tap)) then
				render.text(font_med, pos.x + 104 + 5, pos.y + 45, color.new(255,255,255), 'Exploit: HS')
				render.gradient(pos.x + 104, pos.y + 54, math.floor(2), math.floor(3), color.new(0,255,0,255), color.new(0,0,0,0), 1)
				render.gradient(pos.x + 104, pos.y + 50, math.floor(2), math.floor(3), color.new(0,0,0,0), color.new(0,255,0,255), 1)
				render.rect_filled(pos.x + 104, pos.y + 53, math.floor(2), math.floor(1), color.new(0,255,0, 255))

			end
			if not (ui.get_keybind_state(keybinds.hide_shots)) and not (ui.get_keybind_state(keybinds.double_tap)) and not rechdt then
				render.text(font_med, pos.x + 104 + 5, pos.y + 45, color.new(255,255,255), 'Exploit: FL')
render.gradient(pos.x + 104, pos.y + 54, math.floor(2), math.floor(3), color.new(255,0,0,255), color.new(0,0,0,0), 1)
render.gradient(pos.x + 104, pos.y + 50, math.floor(2), math.floor(3), color.new(0,0,0,0), color.new(255,0,0,255), 1)
render.rect_filled(pos.x + 104, pos.y + 53, math.floor(2), math.floor(1), color.new(255,0,0, 255))


			end
			
if rechdt then
render.text(font_med, pos.x + 104 + 5, pos.y + 45, color.new(255,255,255), 'Exploit: Recharging')
render.gradient(pos.x + 104, pos.y + 54, math.floor(2), math.floor(3), color.new(255,0,0,255), color.new(0,0,0,0), 1)
render.gradient(pos.x + 104, pos.y + 50, math.floor(2), math.floor(3), color.new(0,0,0,0), color.new(255,0,0,255), 1)
render.rect_filled(pos.x + 104, pos.y + 53, math.floor(2), math.floor(1), color.new(255,0,0, 255))
end



end
end
cheat.RegisterCallback("on_paint", paint)


local randomz

events.register_event("player_death", function(e)
    local attacker = e:get_int("attacker")
    local attacker_to_player = engine.get_player_for_user_id(attacker)
    
    local lp_idx = engine.get_local_player_index()
    
    if attacker_to_player == lp_idx then
     phrases = {"☞你被电竞之心自制Fatal.lua打死了！",
                 "CFG and Fatal Lua by QLbz, Dev QQ 3515083265, DC QLbz#1249. ",}  
            randomz = math.random(1,2)
        console.execute_client_cmd("say " .. phrases[randomz])
    end
end)
